# Keep default Android rules.
